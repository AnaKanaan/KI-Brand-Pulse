# streamlit_app.py
import os, time, json, threading, queue, pathlib
import pandas as pd
import streamlit as st

from ki_rep_monitor import run_pipeline

st.set_page_config(page_title='KI-Reputation Monitor', layout='wide')
st.title('🔎 KI-Reputation Monitor — Final3')

# =========================================================
# Session init (nur im UI-Thread)
# =========================================================
if "runner" not in st.session_state:
    st.session_state.runner = {
        "thread": None,
        "cancel": None,
        "events": queue.Queue(),    # worker -> UI
        "jobs_done": 0,
        "jobs_total": 0,
        "start_t": 0.0,
        "log_path": None,           # NDJSON live-log
    }

# =========================================================
# API Keys (Session only)
# =========================================================
with st.expander('🔐 API-Keys (nur Session, keine Speicherung)'):
    openai_key = st.text_input('OpenAI API Key', type='password', placeholder='sk-...')
    google_key = st.text_input('Google API Key', type='password', placeholder='AIza...')
    google_cx  = st.text_input('Google CSE ID (cx)', type='password', placeholder='custom search engine id')
    gemini_key = st.text_input('Gemini API Key', type='password', placeholder='AIza...')
    if st.button('Apply Keys'):
        if openai_key: os.environ['OPENAI_API_KEY'] = openai_key
        if google_key: os.environ['GOOGLE_API_KEY'] = google_key
        if google_cx:  os.environ['GOOGLE_CSE_ID']  = google_cx
        if gemini_key: os.environ['GEMINI_API_KEY'] = gemini_key
        st.success('Keys gesetzt (nur Session).')

# =========================================================
# Sidebar Config
# =========================================================
with st.sidebar:
    st.markdown("### Konfiguration")
    brand  = st.text_input('Brand', 'DAK')
    topic  = st.text_input('Topic', 'KI im Gesundheitswesen')
    market = st.text_input('Market', 'DE')
    comp1  = st.text_input('Competitor 1', 'TK')
    comp2  = st.text_input('Competitor 2', 'AOK')
    comp3  = st.text_input('Competitor 3', '')

    # Available interaction profiles.  Gemini profiles are newly added for free chat and search support.
    profiles = st.multiselect(
        'Profiles',
        ['CHATGPT_NO_SEARCH', 'CHATGPT_SEARCH_AUTO', 'GOOGLE_OVERVIEW', 'GEMINI_NO_SEARCH', 'GEMINI_SEARCH_AUTO'],
        default=['CHATGPT_NO_SEARCH', 'CHATGPT_SEARCH_AUTO', 'GOOGLE_OVERVIEW']
    )

    languages = st.multiselect('Languages', ['de','fr','it','rm','en'], default=['de'])

    # Stakeholder perspective selection.  If none selected a generic perspective is used.
    stakeholders = st.multiselect(
        'Stakeholders',
        ['generic', 'Bewerber', 'Investor', 'Mitarbeitender', 'Endkonsument', 'Business-Kunde', 'Business-Partner', 'Provider', 'Politischer Entscheider'],
        default=['generic']
    )

    categories = st.multiselect('Categories',
                                ['BRANDED','UNBRANDED','THOUGHT_LEADERSHIP','RISK','BENCHMARK'],
                                default=['BRANDED','BENCHMARK','RISK'])

    question_ids_raw = st.text_input('Question IDs (comma-separated)', '')

    topn       = st.number_input('Google CSE Top-N', 1, 10, 5)
    num_runs   = st.number_input('Replicates per question', 1, 10, 1)
    temp_no    = st.slider('Temp (Chat no search)', 0.0, 1.2, 0.5, 0.05)
    temp_auto  = st.slider('Temp (Chat auto-search)', 0.0, 1.2, 0.25, 0.05)
    # Increase default token limits for Pass A to accommodate longer responses
    max_tokens = st.number_input('max_output_tokens (Pass A, no search)', 100, 4096, 4000, 50)
    max_tokens_search = st.number_input('max_output_tokens (Pass A, search)', 200, 8192, 4000, 50)
    wrapper_mode = st.selectbox('Pass-A Wrapper', ['free_emulation','stabilized'], index=0)

    st.markdown("### Model Settings")
    # Default models now reflect the GPT‑5.1 series.  GPT‑5.1 Instant is
    # exposed as gpt-5.1-chat-latest, while GPT‑5.1 Thinking is available as
    # gpt-5.1【677344943524217†L566-L569】.  These defaults can be overridden by
    # environment variables.
    model_chat   = st.text_input('Model (Pass A: Antwort)', os.getenv("MODEL_CHAT", "gpt-5.1-chat-latest"))
    model_pass_b = st.text_input('Model (Pass B: Codierung)', os.getenv("MODEL_PASS_B", "gpt-5.1"))

    if st.button('Apply Model Settings'):
        os.environ["MODEL_CHAT"]   = model_chat.strip()
        os.environ["MODEL_PASS_B"] = model_pass_b.strip()
        st.success("Modelle gesetzt.")

    uploaded = st.file_uploader('Question Library (xlsx, optional)', type=['xlsx'])
    question_xlsx = uploaded if uploaded is not None else 'ki_question_library.xlsx'

    st.markdown("### Debug & Limits")
    debug_level = st.selectbox("Debug-Detailgrad", ["verbose","basic","none"], index=0)
    max_questions = st.number_input("Max. Fragen (Testlauf, 0 = alle)", 0, 2000, 0, 10)

    st.divider()
    run_btn  = st.button('🚀 Run')
    stop_btn = st.button('🛑 Stop')
    clear_btn= st.button('🧹 Clear Logs')

# =========================================================
# Helpers (UI-Thread)
# =========================================================
def parse_ids(s: str):
    if not s or not s.strip(): return None
    out = []
    for p in s.split(','):
        p = p.strip()
        if not p: continue
        try: out.append(int(p))
        except: pass
    return out or None

def ui_event_sink(ev: dict):
    """Nur im UI-Thread st.session_state anfassen."""
    st.session_state.runner["events"].put(ev)
    lp = st.session_state.runner.get("log_path")
    if lp:
        try:
            with open(lp, "a", encoding="utf-8") as f:
                f.write(json.dumps(ev, ensure_ascii=False) + "\n")
        except Exception:
            pass

def eta_text(done: int, total: int, start_t: float) -> str:
    if done <= 0 or total <= 0: return "–"
    elapsed = max(0.001, time.time() - start_t)
    rate = done / elapsed
    if rate <= 0: return "–"
    remain = total - done
    sec_left = int(remain / rate)
    return f"{sec_left // 60:02d}:{sec_left % 60:02d}"

def save_uploaded_file_to_tmp(uploaded_file) -> str:
    if isinstance(uploaded_file, str):
        return uploaded_file
    path = f"/tmp/_qlib_{int(time.time())}.xlsx"
    with open(path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return path

# =========================================================
# Runner (Worker darf KEIN st.* benutzen)
# =========================================================
def start_worker():
    if not os.getenv('OPENAI_API_KEY'):
        st.error('Bitte zuerst OpenAI API Key setzen.')
        return

    # Queue leeren
    q: queue.Queue = st.session_state.runner["events"]
    while not q.empty():
        try: q.get_nowait()
        except: break

    q_path = save_uploaded_file_to_tmp(question_xlsx)
    # schnelle Spaltenvorschau
    try:
        cols = list(pd.read_excel(q_path, sheet_name="Questions").columns)
        st.sidebar.write("Questions sheet columns:", cols)
    except Exception as ex:
        st.sidebar.write("Questions sheet columns: <Fehler>", str(ex))

    out_name = f'out_{int(time.time())}.xlsx'
    cancel_event = threading.Event()
    st.session_state.runner["cancel"] = cancel_event
    st.session_state.runner["start_t"] = time.time()
    st.session_state.runner["jobs_done"] = 0
    st.session_state.runner["jobs_total"] = 0

    log_path = f"/tmp/_run_{int(time.time())}.ndjson"
    st.session_state.runner["log_path"] = log_path
    try:
        pathlib.Path(log_path).write_text("", encoding="utf-8")
    except Exception:
        st.session_state.runner["log_path"] = None
        log_path = None

    # Worker-lokale Sinks (keine session_state Zugriffe!)
    def worker_event_sink(ev: dict):
        try:
            q.put(ev)
            if log_path:
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(ev, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def _progress(ev: dict):
        # nur in Queue schieben, UI aktualisiert Counters beim Drain
        worker_event_sink(ev)

    def _work():
        try:
            res = run_pipeline(
                brand=brand, topic=topic, market=market,
                languages=languages, profiles=profiles,
                question_xlsx=q_path, out_xlsx=out_name,
                domain_seed_csv='domain_type_seed.csv',
                coder_prompts_json='coder_prompts_passB.json',
                topn=int(topn), num_runs=int(num_runs),
                categories=categories, question_ids=parse_ids(question_ids_raw),
                comp1=comp1, comp2=comp2, comp3=comp3,
                temperature_chat_no=float(temp_no), temperature_chat_search=float(temp_auto),
                max_tokens=int(max_tokens), wrapper_mode=wrapper_mode,
                progress=_progress, cancel_event=cancel_event,
                debug_level=debug_level, max_questions=int(max_questions),
                passA_search_tokens=int(max_tokens_search),
                stakeholders=stakeholders
            )
            worker_event_sink({"t": time.time(), "phase": "done", "msg": json.dumps(res)})
        except Exception as ex:
            worker_event_sink({"t": time.time(), "phase": "error", "msg": str(ex)})

    th = threading.Thread(target=_work, name="runner-thread", daemon=True)
    st.session_state.runner["thread"] = th
    th.start()

def stop_worker():
    c = st.session_state.runner.get("cancel")
    if c: c.set()

def clear_logs():
    q: queue.Queue = st.session_state.runner["events"]
    while not q.empty():
        try: q.get_nowait()
        except: break
    st.session_state.runner["log_path"] = None

# Buttons
if run_btn and (st.session_state.runner["thread"] is None or not st.session_state.runner["thread"].is_alive()):
    start_worker()

if stop_btn:
    stop_worker()

if clear_btn:
    clear_logs()

# =========================================================
# Live-Status & Logs
# =========================================================
is_running = bool(st.session_state.runner.get("thread") and st.session_state.runner["thread"].is_alive())
jobs_done  = st.session_state.runner.get("jobs_done", 0)
jobs_total = st.session_state.runner.get("jobs_total", 0)
start_t    = st.session_state.runner.get("start_t", time.time())
log_path   = st.session_state.runner.get("log_path")

st.divider()
c1, c2, c3, c4 = st.columns(4)
with c1: st.markdown("**Status**");      st.write("Läuft…" if is_running else "Idle")
with c2: st.markdown("**Fortschritt**"); st.write(f"{jobs_done}/{jobs_total}" if jobs_total else "–")
with c3: st.markdown("**ETA**");         st.write(eta_text(jobs_done, jobs_total, start_t))
with c4:
    if log_path and os.path.exists(log_path):
        st.download_button("📥 Debug-Logs (NDJSON)", data=open(log_path,"rb").read(), file_name=os.path.basename(log_path))

progress_bar = st.progress(min(1.0, jobs_done / jobs_total) if jobs_total else 0.0)

st.markdown('### 🪵 Debug-Protokoll (live)')
log_box = st.container()
with log_box:
    drained = 0
    while drained < 1000 and not st.session_state.runner["events"].empty():
        ev = st.session_state.runner["events"].get()
        drained += 1

        # Fortschritt im UI aktualisieren (hier ist Streamlit-Kontext vorhanden)
        if ev.get("phase") == "progress":
            meta = ev.get("meta") or {}
            st.session_state.runner["jobs_done"]  = int(meta.get("done", 0))
            st.session_state.runner["jobs_total"] = int(meta.get("total", 0))

        phase = ev.get("phase", "")
        msg   = ev.get("msg", "")
        meta  = ev.get("meta") or {}
        tstr  = time.strftime("%H:%M:%S", time.localtime(ev.get("t", time.time())))
        lines = [f"{tstr} {phase} — {msg}"]

        # Quellen hübsch anzeigen
        cits = meta.get("citations") or []
        if cits:
            lines.append("    Quellen:")
            for j, c in enumerate(cits, 1):
                dom = c.get("domain", "")
                tit = (c.get("title") or dom or "").strip()
                sn  = (c.get("snippet") or "").strip()
                url = c.get("url", "")
                if sn:
                    lines.append(f"      {j}. {tit} ({dom}) – {sn} – {url}")
                else:
                    lines.append(f"      {j}. {tit} ({dom}) – {url}")

        pe = meta.get("prompt_excerpt"); ae = meta.get("answer_excerpt")
        if pe: lines.append(f"    prompt: {pe}")
        if ae: lines.append(f"    answer: {ae}")

        st.code("\n".join(lines))

# =========================================================
# Ergebnis-Panel wenn fertig
# =========================================================
if not is_running:
    out_file = None
    try:
        candidates = [f for f in os.listdir(".") if f.startswith("out_") and f.endswith(".xlsx")]
        if candidates:
            out_file = max(candidates, key=lambda p: os.path.getmtime(p))
    except Exception:
        pass

    if out_file and os.path.exists(out_file):
        st.success(f'Fertig: {out_file}')
        with open(out_file, "rb") as fh:
            st.download_button('📥 Download Excel', data=fh.read(), file_name=out_file)

        try:
            xls = pd.ExcelFile(out_file)
            runs = pd.read_excel(xls, 'Runs') if "Runs" in xls.sheet_names else pd.DataFrame()
            norm = pd.read_excel(xls, 'Normalized') if "Normalized" in xls.sheet_names else pd.DataFrame()
            evid = pd.read_excel(xls, 'Evidence') if "Evidence" in xls.sheet_names else pd.DataFrame()
            cfg  = pd.read_excel(xls, 'Config') if "Config" in xls.sheet_names else pd.DataFrame()
            raw  = pd.read_excel(xls, 'RawAnswers') if "RawAnswers" in xls.sheet_names else pd.DataFrame()
        except Exception as ex:
            st.error(f"Excel lesen fehlgeschlagen: {ex}")
            runs = norm = evid = cfg = raw = pd.DataFrame()

        st.subheader('📊 KPIs')
        col1, col2, col3, col4, col5, col6 = st.columns(6)

        # robust gegen pandas 3.0
        def _bool_mean(series: pd.Series) -> float:
            if series is None or series.empty: return 0.0
            s = series.astype('boolean').fillna(False)
            return float(s.mean())

        def _num_mean(series: pd.Series) -> float:
            if series is None or series.empty: return 0.0
            return pd.to_numeric(series, errors='coerce').fillna(0).mean()

        inc   = _bool_mean(norm.get('inclusion', pd.Series(dtype='boolean')))
        sent  = _num_mean(norm.get('aspect_scores.sentiment', pd.Series(dtype='float')))
        fresh = _num_mean(norm.get('freshness_index', pd.Series(dtype='float')))

        evid_by_run = (evid.groupby('run_id').size() if not evid.empty else pd.Series(dtype=int))
        ev_rate = (evid_by_run.gt(0).mean() if not evid_by_run.empty else 0.0)
        dom_div = int(evid['domain'].nunique()) if not evid.empty and 'domain' in evid.columns else 0

        lbl_col = norm.get('sentiment_label', pd.Series(dtype='object'))
        lbl_counts = lbl_col.value_counts() if not lbl_col.empty else pd.Series(dtype='int')
        pos_share  = (float(lbl_counts.get('positive', 0)) / max(int(lbl_counts.sum()), 1)) if not lbl_counts.empty else 0.0

        col1.metric('Inclusion Rate', f'{inc*100:.1f}%')
        col2.metric('Sentiment Ø', f'{sent:+.2f}')
        col3.metric('Freshness Index', f'{fresh:.2f}')
        col4.metric('% Runs mit Belegen', f'{ev_rate*100:.1f}%')
        col5.metric('Domain-Diversität', f'{dom_div}')
        col6.metric('Positiv-Label Anteil', f'{pos_share*100:.1f}%')

        c1, c2 = st.columns(2)
        with c1:
            st.markdown('**Domain Types**')
            if not evid.empty and 'domain_type' in evid.columns:
                dtc = evid['domain_type'].value_counts().reset_index()
                dtc.columns = ['domain_type','count']
                st.bar_chart(dtc.set_index('domain_type'))
            else:
                st.info('Keine Evidence-Daten.')
        with c2:
            st.markdown('**Freshness Buckets**')
            if not evid.empty and 'freshness_bucket' in evid.columns:
                order = ['today','≤7d','≤30d','≤90d','≤365d','>365d','unknown']
                fb = evid['freshness_bucket'].value_counts().reindex(order).fillna(0).reset_index()
                fb.columns = ['bucket','count']
                st.bar_chart(fb.set_index('bucket'))
            else:
                st.info('Keine Evidence-Daten.')

        st.markdown('### Profile × Language — Inclusion Rate')
        try:
            inc_pf = norm.assign(incl=norm['inclusion'].astype('boolean').fillna(False)) \
                         .groupby(['profile','language'])['incl'].mean().reset_index()
            inc_pf['incl'] = (inc_pf['incl']*100).round(1)
            inc_pf = inc_pf.pivot(index='profile', columns='language', values='incl').fillna(0)
            st.bar_chart(inc_pf)
        except Exception:
            st.info('Nicht genug Daten für Profile×Language.')

        st.markdown('### Sentiment by Profile')
        try:
            s_pf = pd.to_numeric(norm['aspect_scores.sentiment'], errors='coerce') \
                       .groupby(norm['profile']).mean().to_frame('sentiment')
            st.bar_chart(s_pf)
        except Exception:
            pass

        st.subheader('Runs'); st.dataframe(runs, use_container_width=True, hide_index=True)
        st.subheader('Evidence'); st.dataframe(evid, use_container_width=True, hide_index=True)
        st.subheader('Normalized (flattened JSON)'); st.dataframe(norm, use_container_width=True, hide_index=True)
        if not raw.empty:
            st.subheader('Raw Answers (Pass A)'); st.dataframe(raw, use_container_width=True, hide_index=True)
        st.subheader('Config'); 
        if not cfg.empty: st.table(cfg)
    else:
        st.info('Keys setzen (optional), konfigurieren und **Run** starten.')
else:
    st.info('Lauf aktiv — Logs & Fortschritt siehe oben. Mit **Stop** kannst du den Run abbrechen.')
